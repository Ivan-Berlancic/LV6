/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zad2;

public class Direktor extends Zaposlenik{
    @Override
    public void radi(){
        System.out.println("Odlucujem");
    }
    
    @Override
    public void predstaviSe(){
        super.predstaviSe();
        System.out.println(Direktor.class.getSimpleName());
    }
}
