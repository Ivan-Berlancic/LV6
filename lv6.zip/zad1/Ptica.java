/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zad1;

/**
 *
 * @author student
 */
public class Ptica extends Zivotinja{
    Ptica(){
        vrsta="ptica";
    }
    
    @Override
    void kreciSe(){
        System.out.println("letim");
    }
}
